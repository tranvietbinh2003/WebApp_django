from django.conf import settings
from django.contrib.auth.models import User
from django.urls import reverse
from django.db import models


class Post(models.Model):
    title = models.CharField(max_length=100)
    body = models.TextField()
    date = models.DateTimeField(auto_now_add=True)
    image = models.ImageField()
    audio = models.FileField(upload_to='madia/music',null = True)
    author = models.ForeignKey(User, on_delete=models.CASCADE,null=True)
    description = models.TextField(max_length=1000, null=True, default=None)
    content = models.TextField(max_length=10000, null=True, default=None)

    def __str__(self):
        return self.title
    def get_absolute_url(self):
        return reverse('blog')